﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Web_Browser
{
    public class BrowserHelper
    {
        public HttpResponse Search(string url)
        {
            return GetHTTPRequest(url);
        }

        private HttpResponse GetHTTPRequest(string url)
        {
            try
            {
                
                var request = (HttpWebRequest)WebRequest.Create(url);
                var response = (HttpWebResponse)request.GetResponse();

                string responseString;

                using (var stream = response.GetResponseStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        responseString = reader.ReadToEnd();
                    }
                }

                var httpResponse = new HttpResponse
                {
                    httpResponse = response,
                    httpResponseString = responseString
                };
                
                return httpResponse;
            }
            catch (Exception e)
            {
                var httpResponse = new HttpResponse
                {
                    httpResponse = null,
                    httpResponseString = "Bad Request"
                };

                return httpResponse;
            }
        }
    }
}


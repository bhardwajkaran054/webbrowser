﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Web_Browser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            responseRichTextBox.Text = "Searching...";
            var url = searchTextBox.Text;

            var browserHelper = new BrowserHelper();
            var result = browserHelper.Search(url);

            var responseText = result.httpResponseString;
            var response = result.httpResponse;
            var responseCode = string.Empty;

            if (response?.StatusCode != null)
            {
                responseCode = (int)response.StatusCode + " " + response.StatusCode.ToString();
                this.Text = responseCode;
            }
            else
                this.Text = "Browser";

            responseRichTextBox.Text = responseText;
        }
    }
}
